#!/bin/bash
touch /var/app/file
sudo chown -R webapp:webapp /var/app/*